# ECG Data Acquisition and Analysis (Lab 4)

This project contains data and code related to Lab 4 from EEEE 536/636 – Biorobotics/Cybernetics.

## Contents
- `ecg_data.csv`: Raw heart rate data exported from Wahoo Fitness app.
- `heart_rate_plot.png`: Time-series plot of heart rate.
- `heart_rate_histogram.png`: Histogram of heart rate distribution.
- `Lab_4_ECG_Report.docx`: Final lab report with theory, methodology, results, and discussion.
- `ecg_analysis.ipynb`: Python code to analyze and visualize heart rate data.

## Tools Used
- Wahoo Fitness App
- Golden Cheetah
- Python (pandas, matplotlib)

## Instructions
1. Upload this folder to your GitHub repository.
2. Open `ecg_analysis.ipynb` in Google Colab to run the code and reproduce the results.

