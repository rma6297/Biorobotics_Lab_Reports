# EEG Signal Acquisition and Analysis (Lab 2)

This GitHub folder contains the experiment files for Lab 2 – EEG Data Collection using the Unicorn Suite and Unicorn EEG Cap.

## Files Included:
- `Lab_2_EEG_Manual.pdf`: The official lab instructions and background.
- `eeg_analysis.ipynb`: Jupyter notebook for analyzing EEG signal data.

## Instructions:
1. Collect EEG signal data using Unicorn Suite and save it as `.csv`.
2. Open `eeg_analysis.ipynb` in Google Colab or Jupyter Notebook.
3. Upload the recorded `.csv` EEG file and follow the notebook steps for visualization.

## Tools Required:
- Unicorn Suite (EEG data collection)
- Google Colab / Jupyter Notebook
- Python with `pandas`, `matplotlib`, `scipy`

