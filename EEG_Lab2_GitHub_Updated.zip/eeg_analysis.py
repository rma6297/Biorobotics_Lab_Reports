import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt

# Load EEG data CSV (replace with actual filename)
df = pd.read_csv('your_eeg_data.csv')
df.head()

# Bandpass filter function for EEG
def bandpass_filter(data, lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return filtfilt(b, a, data)


# Example of plotting filtered EEG channel
# Replace 'Channel1' with actual column name
filtered = bandpass_filter(df['Channel1'], 0.1, 30, fs=250)
plt.figure(figsize=(12, 4))
plt.plot(filtered)
plt.title('Filtered EEG Signal (Channel1)')
plt.xlabel('Samples')
plt.ylabel('Amplitude')
plt.grid(True)
plt.show()