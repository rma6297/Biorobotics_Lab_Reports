
import pandas as pd
import matplotlib.pyplot as plt
import os

# Load EMG data
file_path = "output_file.csv"
df = pd.read_csv(file_path)

# Print preview of the data
print("Data shape:", df.shape)
print(df.head())

# Check if at least 8 EMG channels are present
if df.shape[1] >= 8:
    emg_data = df.iloc[:, :8]  # Take only first 8 columns as EMG channels
    emg_rectified = emg_data.abs()  # Rectify the signals

    # Plot raw EMG signals
    fig, axs = plt.subplots(8, 1, figsize=(10, 10), sharex=True)
    for i in range(8):
        axs[i].plot(emg_data.iloc[:, i])
        axs[i].set_ylabel(f'Ch.{i+1}')
        axs[i].set_ylim([-100, 100])
    plt.suptitle("Raw EMG Signals (8 Channels)")
    plt.tight_layout()
    plt.savefig("emg_raw_plot.png")
    plt.show()

    # Plot rectified EMG signals
    fig, axs = plt.subplots(8, 1, figsize=(10, 10), sharex=True)
    for i in range(8):
        axs[i].plot(emg_rectified.iloc[:, i], color='orange')
        axs[i].set_ylabel(f'Ch.{i+1}')
    plt.suptitle("Rectified EMG Signals (8 Channels)")
    plt.tight_layout()
    plt.savefig("emg_rectified_plot.png")
    plt.show()

else:
    print("The file does not contain 8 EMG channels. Found only", df.shape[1])
