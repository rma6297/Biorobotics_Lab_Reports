# EOG Signal Acquisition and Analysis (Lab 3)

This GitHub folder contains the experiment files for Lab 3 – Electrooculography (EOG) using Biosignalplux.

## Files Included:
- `Houssein_Reading_Horizontal.txt`: Raw EOG data captured via OpenSignals software.
- `eog_results.png`: Screenshot of the analysis (horizontal movement).
- `Lab_3_EOG_Report.docx`: Final formatted lab report in Word format.
- `eog_analysis.ipynb`: Python notebook for visualizing and processing EOG data.

## Tools Used:
- Biosignalplux OpenSignals Suite
- Google Colab (for analysis)
- Python libraries: `numpy`, `matplotlib`, `pandas`

## Instructions:
1. Open `eog_analysis.ipynb` in Google Colab.
2. Upload the `.txt` data file.
3. Execute the notebook to view signals and detect movements.

