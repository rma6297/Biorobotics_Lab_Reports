import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

filename = 'Houssein_Reading_Horizontal.txt'
data = pd.read_csv(filename, sep='\t', comment='#', header=None)
data.columns = ['nSeq', 'DI', 'MICRO', 'EMG', 'ACC_X', 'ACC_Y', 'ACC_Z', 'MAG_X', 'MAG_Y', 'MAG_Z']
data.head()

# Plot raw EOG signal from EMG (assumed EOG signal on channel index 3)
plt.figure(figsize=(12, 4))
plt.plot(data['EMG'], label='EOG Signal')
plt.title('Horizontal Eye Movement Signal')
plt.xlabel('Sample Index')
plt.ylabel('Signal Value')
plt.grid(True)
plt.legend()
plt.show()