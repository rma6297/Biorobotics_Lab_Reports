
import pandas as pd
import matplotlib.pyplot as plt

# Load ECG CSV file
df = pd.read_csv('2025-04-17-082206-WAHOOAPPIOSE551-1-0-record.csv')

# Extract time and heart rate columns if they exist
if 'Time (s)' in df.columns and 'ECG (mV)' in df.columns:
    time = df['Time (s)']
    ecg = df['ECG (mV)']
    
    # Plot ECG signal
    plt.figure(figsize=(12, 4))
    plt.plot(time, ecg, color='blue')
    plt.title('ECG Signal Over Time')
    plt.xlabel('Time (s)')
    plt.ylabel('ECG (mV)')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('ecg_plot.png')
    plt.close()

# If heart rate column exists, make a histogram
if 'Heart Rate (bpm)' in df.columns:
    heart_rate = df['Heart Rate (bpm)']
    
    plt.figure(figsize=(6, 4))
    plt.hist(heart_rate.dropna(), bins=20, color='green', edgecolor='black')
    plt.title('Heart Rate Distribution')
    plt.xlabel('Heart Rate (bpm)')
    plt.ylabel('Frequency')
    plt.tight_layout()
    plt.savefig('heart_rate_histogram.png')
    plt.close()
